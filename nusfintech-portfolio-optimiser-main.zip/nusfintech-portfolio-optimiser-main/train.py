from backend.model import train_model

train_model()   
